
public interface Dockable
{
	void dockWith(Dockable d);
	void openHatch();
	String getName();
	
}
